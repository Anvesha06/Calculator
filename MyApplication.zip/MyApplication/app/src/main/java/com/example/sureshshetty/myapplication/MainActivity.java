package com.example.sureshshetty.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.sureshshetty.myapplication.R;

public class MainActivity extends AppCompatActivity {
    Button btn0,btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9,btnp,btns,btnm,btnd,btne,btnc,btndec;
    EditText ed1;
    float V1, V2,v3;
    boolean badd, bsub, bmul, bdiv ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn0= (Button) findViewById(R.id.b0);
        btn1= (Button) findViewById(R.id.b1);
        btn2= (Button) findViewById(R.id.b2);
        btn3= (Button) findViewById(R.id.b3);
        btn4= (Button) findViewById(R.id.b4);
        btn5= (Button) findViewById(R.id.b5);
        btn6= (Button) findViewById(R.id.b6);
        btn7= (Button) findViewById(R.id.b7);
        btn8= (Button) findViewById(R.id.b8);
        btn9= (Button) findViewById(R.id.b9);
        btnp= (Button) findViewById(R.id.bp);
        btns= (Button) findViewById(R.id.bs);
        btnm= (Button) findViewById(R.id.bm);
        btnd= (Button) findViewById(R.id.bd);
        btne= (Button) findViewById(R.id.be);
        btnc= (Button) findViewById(R.id.bc);
        btndec= (Button) findViewById(R.id.bdec);
        ed1=(EditText) findViewById(R.id.et);

        btn0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ed1.setText(ed1.getText()+"0");
            }
        });
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ed1.setText(ed1.getText()+"1");
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ed1.setText(ed1.getText()+"2");
            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ed1.setText(ed1.getText()+"3");
            }
        });
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ed1.setText(ed1.getText()+"4");
            }
        });
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ed1.setText(ed1.getText()+"5");
            }
        });
        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ed1.setText(ed1.getText()+"6");
            }
        });
        btn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ed1.setText(ed1.getText()+"7");
            }
        });
        btn8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ed1.setText(ed1.getText()+"8");
            }
        });
        btn9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ed1.setText(ed1.getText()+"9");
            }
        });
        btndec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ed1.setText(ed1.getText()+".");
            }
        });

        btnp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                V1 = Float.parseFloat(ed1.getText() +"");
                badd = true;
                ed1.setText(ed1.getText()+"+");
            }
        });

        btns.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                V1 = Float.parseFloat(ed1.getText() +"");
                bsub = true;
                ed1.setText(ed1.getText()+"-");

            }
        });

        btnm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                V1 = Float.parseFloat(ed1.getText() + "");
                bmul = true;
                ed1.setText(ed1.getText()+"*");

            }
        });

        btnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                V1 = Float.parseFloat(ed1.getText() +"");
                bdiv = true;
                ed1.setText(ed1.getText()+"/");
            }
        });
        btne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (badd == true){
                    String cs=ed1.getText().toString();
                    String[] sep=cs.split("\\+");
                    V2 = Float.parseFloat(sep[1]+"");
                    v3=V1+V2;
                    String ans=Float.toString(v3);
                    ed1.setText(ed1.getText()+"="+ans);
                    badd=false;
                }


                if (bsub == true){
                    String cs=ed1.getText().toString();
                    String[] sep=cs.split("-");
                    V2 = Float.parseFloat(sep[1]+ "");
                    v3=V1-V2;
                    String ans=Float.toString(v3);
                    ed1.setText(ed1.getText()+"="+ans);
                    bsub=false;
                }

                if (bmul == true){
                    String cs=ed1.getText().toString();
                    String[] sep=cs.split("\\*");
                    V2 = Float.parseFloat(sep[1]+"");
                    v3=V1*V2;
                    String ans=Float.toString(v3);
                    ed1.setText(ed1.getText()+"="+ans);
                    bmul=false;
                }

                if (bdiv == true){
                    String cs=ed1.getText().toString();
                    String[] sep=cs.split("/");
                    V2 = Float.parseFloat(sep[1]+"");
                    v3=V1/V2;
                    String ans=Float.toString(v3);
                    ed1.setText(ed1.getText()+"="+ans);
                    bdiv=false;
                }
            }
        });


        btnc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ed1.setText("");
            }
        });




    }
}

